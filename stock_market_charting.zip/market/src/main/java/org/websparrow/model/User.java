package org.websparrow.model;

public class User {

	private int lid;
	private String userId, password;
	private String usertype;
	private String email;
	private String mobile;
	private String confirm;


	@Override
	public String toString() {
		return "User [lid=" + lid + ", userId=" + userId + ", password=" + password + ", usertype=" + usertype
				+ ", email=" + email + ", mobile=" + mobile + ", confirm=" + confirm + "]";
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getConfirm() {
		return confirm;
	}

	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
