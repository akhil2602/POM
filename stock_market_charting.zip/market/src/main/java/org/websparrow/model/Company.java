package org.websparrow.model;

public class Company {

	private int cid;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	private String Company_Name;
	private int Turnover;
	private String CEO;
	private int BOD;
	private String LExchanges;
	private String Sector;
	private String Brief_writeup;
	public String getCompany_Name() {
		return Company_Name;
	}
	public void setCompany_Name(String company_Name) {
		Company_Name = company_Name;
	}
	public int getTurnover() {
		return Turnover;
	}
	public void setTurnover(int turnover) {
		Turnover = turnover;
	}
	public String getCEO() {
		return CEO;
	}
	public void setCEO(String cEO) {
		CEO = cEO;
	}
	public int getBOD() {
		return BOD;
	}
	public void setBOD(int bOD) {
		BOD = bOD;
	}
	public String getLExchanges() {
		return LExchanges;
	}
	public void setLExchanges(String lExchanges) {
		LExchanges = lExchanges;
	}
	public String getSector() {
		return Sector;
	}
	public void setSector(String sector) {
		Sector = sector;
	}
	public String getBrief_writeup() {
		return Brief_writeup;
	}
	public void setBrief_writeup(String brief_writeup) {
		Brief_writeup = brief_writeup;
	}

	
}
