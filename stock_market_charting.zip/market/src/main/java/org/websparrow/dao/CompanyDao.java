package org.websparrow.dao;

import java.util.List;

import org.websparrow.model.Company;

public interface CompanyDao {

	public int registerCompany(Company company);
	 public void updateCompany(Company company);
	    public List<Company> getAllCompany();
	    public Company getCompanyById(int cid);
	
}
