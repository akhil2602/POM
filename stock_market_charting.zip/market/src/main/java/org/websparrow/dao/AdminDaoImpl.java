package org.websparrow.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.websparrow.model.Admin;

@Repository
public class AdminDaoImpl implements AdminDao {

	private JdbcTemplate jdbcTemplate;

	public AdminDaoImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}

	public String loginAdmin(Admin admin) {
		// TODO Auto-generated method stub
String sql = "SELECT USER_NAME FROM ADMIN_DATA WHERE USER_NAME=? AND PASSWORD=?";
		
		try {

			String username = jdbcTemplate.queryForObject(sql, new Object[] {
					admin.getUsername(), admin.getPassword() }, String.class);

			return username;
			
		} catch (Exception e) {
		
		
		return null;
	}

	}
}

