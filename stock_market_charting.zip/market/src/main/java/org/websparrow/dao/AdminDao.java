package org.websparrow.dao;

import org.websparrow.model.Admin;

public interface AdminDao {

	public String loginAdmin(Admin admin);
	
}


