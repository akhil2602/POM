package org.websparrow.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.websparrow.model.Company;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

@Repository
public class CompanyDaoImpl implements CompanyDao{

	private JdbcTemplate jdbcTemplate;

	public CompanyDaoImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}
	
	
	
	public int registerCompany(Company company) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO Company VALUES(?,?,?,?,?,?,?)";

		try {
			
			int counter = jdbcTemplate.update(sql, new Object[] { company.getCompany_Name(), company.getTurnover(), company.getCEO(), company.getBOD(), company.getLExchanges(), company.getSector(), company.getBrief_writeup() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	
	}



	public void updateCompany(Company company) {
		// TODO Auto-generated method stub
		String sql = "update Company set cname =?, turnover=?, ceo=?,bod=?, exchange=?,sector=?,write=? where id=?";
        jdbcTemplate.update(sql, new Object[]
        {
        	company.getCompany_Name(), company.getTurnover(), company.getCEO(), company.getBOD(), company.getLExchanges(), company.getSector(), company.getBrief_writeup() });
		
	}



	public List<Company> getAllCompany()
	{
        String sql = "select * from Company";

        List<Company> employeeList = jdbcTemplate.query(sql, new ResultSetExtractor<List<Company>>()
        {
            public List<Company> extractData(ResultSet rs) throws SQLException, DataAccessException
            {
                List<Company> list = new ArrayList<Company>();
                while (rs.next())
                {
                    Company company = new Company();
                    company.setCompany_Name(rs.getString(1));
                    company.setTurnover(rs.getInt(2));
                    company.setCEO(rs.getString(3));
                    company.setBOD(rs.getInt(4));
                    company.setLExchanges(rs.getString(5));
                    company.setSector(rs.getString(6));
                    company.setBrief_writeup(rs.getString(7));
                }
                    return list;
                }
              
            

        });
        return employeeList;
    }




	@SuppressWarnings("unchecked")
	public Company getCompanyById(int cid) {
		// TODO Auto-generated method stub
		 String sql = "select * from Company where id=?";
		 Company company = (Company) jdbcTemplate.queryForObject(sql, new Object[]
	        { cid }, new RowMapper()
	        {
	            public Company mapRow(ResultSet rs, int rowNum) throws SQLException
	            {
	            	Company company = new Company();
                    company.setCompany_Name(rs.getString(1));
                    company.setTurnover(rs.getInt(2));
                    company.setCEO(rs.getString(3));
                    company.setBOD(rs.getInt(4));
                    company.setLExchanges(rs.getString(5));
                    company.setSector(rs.getString(6));
                    company.setBrief_writeup(rs.getString(7));
                   return company;
	            }
	        });
	        return company;
	}

}
