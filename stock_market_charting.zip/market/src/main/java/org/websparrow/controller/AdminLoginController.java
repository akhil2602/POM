package org.websparrow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.websparrow.dao.AdminDao;
import org.websparrow.model.Admin;


@Controller
public class AdminLoginController {

	@Autowired
	private AdminDao adminDao;

	@RequestMapping(value = "/adminlogin", method = RequestMethod.POST)
	public ModelAndView adminLogin(@RequestParam("username") String username, @RequestParam("password") String password) {

		ModelAndView mv1 = new ModelAndView();

		Admin admin = new Admin();
		admin.setUsername(username);
		admin.setPassword(password);

		String name = adminDao.loginAdmin(admin);

		if (name != null) {

//			mv.addObject("msg", "Welcome " + name + ", You have successfully logged in.");
			mv1.setViewName("welcomeadmin");

		} else {

			mv1.addObject("msg", "Invalid user id or password.");
			mv1.setViewName("loginadmin");
		}

		return mv1;

	}

}



